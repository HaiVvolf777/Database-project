
public class Payments {
    int id;
    String method;
    String condition;
}
